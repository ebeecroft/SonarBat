package sonar.gamestates.states.levels.stages.entities.animations.mobs;

public class SonarBat extends Mob
{
	SonarBat(MobBuilder buildMob){super(buildMob);}
	void update()
	{
		
	}
}