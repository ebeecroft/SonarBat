package sonar.gamestates;

public class StateHolder
{
	//Holds all of the states that are currently available in the game.
	static final int menuState = 0;
	public static final int passwordState = 1;
	public static final int starterStage = 2;
}