package sonar.gamestates.states.levels.stages;

import sonar.gamestates.states.levels.LM;
import sonar.gamestates.states.levels.Level;
import sonar.gamestates.states.levels.LevelBuilder;

public class StarterStage1 extends Level
{
	public StarterStage1(LevelBuilder buildLevel, LM lm){super(buildLevel, lm);}
}