package sonar.gamestates.states;

import sonar.gamestates.GSM;
import sonar.gamestates.GameState;
import sonar.gamestates.StateBuilder;

public class Inventory extends GameState
{
	public Inventory(StateBuilder buildState, GSM gsm){super(buildState, gsm);}
}