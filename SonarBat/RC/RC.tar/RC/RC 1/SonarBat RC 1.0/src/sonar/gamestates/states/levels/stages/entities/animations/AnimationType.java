package sonar.gamestates.states.levels.stages.entities.animations;

import sonar.gamestates.states.levels.stages.entities.Sprite;

public interface AnimationType
{
	Sprite getSprite();
	String animType();
}