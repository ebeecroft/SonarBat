package sonar.gamestates;

class StateHolder
{
	static final int menuState = 0;
	static final int passwordState = 1;
	static final int starterStage = 2;
}